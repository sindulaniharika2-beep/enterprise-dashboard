module.exports = [
"[project]/.next-internal/server/app/overview/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_overview_page_actions_c1a7b4fc.js.map